import random
import sys

def integer_check(num):
    try:
        int(num)
        return True
    except ValueError:
        return False

n = sys.argv[1]

if not integer_check(n) or int(n) < 1:
    print("Invalid input. Please provide a positive integer.")
    sys.exit(1)

random_int = random.sample(range(100), int(n))  

for num in random_int:
    print(num)

